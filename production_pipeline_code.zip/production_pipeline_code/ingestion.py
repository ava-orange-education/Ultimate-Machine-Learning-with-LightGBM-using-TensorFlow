import pandas as pd

def ingest_data():
    return pd.read_csv("interactions.csv")