def validate_data(df):
    required = {"user_id", "item_id", "interaction_strength"}
    if not required.issubset(df.columns):
        raise ValueError("Missing required columns")
    if df.isnull().any().any():
        raise ValueError("Null values detected")
    return df