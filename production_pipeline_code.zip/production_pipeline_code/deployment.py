def deploy_model(model):
    model.save("models/latest")
    print("Model deployed successfully")