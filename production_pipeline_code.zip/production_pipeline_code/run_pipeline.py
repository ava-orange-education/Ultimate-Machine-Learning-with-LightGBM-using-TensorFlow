from ingestion import ingest_data
from validation import validate_data
from features import build_features
from training import train_model
from evaluation import evaluate_model
from deployment import deploy_model

def run():
    raw_data = ingest_data()
    validated_data = validate_data(raw_data)
    features = build_features(validated_data)
    model = train_model(features)

    if evaluate_model(model, features):
        deploy_model(model)
    else:
        raise RuntimeError("Model evaluation failed")

if __name__ == "__main__":
    run()