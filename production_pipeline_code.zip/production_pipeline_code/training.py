import tensorflow as tf
from tensorflow.keras import layers, Model

def train_model(df):
    users = df["user_id"].values
    items = df["item_id"].values
    y = df["interaction_strength"].values

    user_input = layers.Input(shape=(1,))
    item_input = layers.Input(shape=(1,))

    user_emb = layers.Embedding(1000, 64)(user_input)
    item_emb = layers.Embedding(1000, 64)(item_input)

    x = layers.Concatenate()([
        layers.Flatten()(user_emb),
        layers.Flatten()(item_emb)
    ])

    x = layers.Dense(64, activation="relu")(x)
    output = layers.Dense(1)(x)

    model = Model([user_input, item_input], output)
    model.compile(optimizer="adam", loss="mse")
    model.fit([users, items], y, epochs=5, batch_size=256)
    return model