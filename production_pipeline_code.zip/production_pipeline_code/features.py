def build_features(df):
    df["interaction_strength"] = df["interaction_strength"].clip(0, 5)
    return df