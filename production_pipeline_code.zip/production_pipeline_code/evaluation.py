import numpy as np

def evaluate_model(model, df):
    preds = model.predict([df["user_id"], df["item_id"]])
    mse = np.mean((preds.flatten() - df["interaction_strength"]) ** 2)
    return mse < 1.0